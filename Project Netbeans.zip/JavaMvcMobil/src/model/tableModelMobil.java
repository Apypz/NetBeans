/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

import java.util.List;
import javax.swing.table.AbstractTableModel;

/**
 *
 * @author USER
 */
public class tableModelMobil extends AbstractTableModel{
    
    List<Mobil> list_mobil;

    public tableModelMobil(List<Mobil> list_mobil) {
        this.list_mobil = list_mobil;
    }

    @Override
    public int getRowCount() {
         return list_mobil.size();
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public int getColumnCount() {
        return 2;
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column) {
            case 0:
                return list_mobil.get(row).getJenis_mobil();
            case 1:
                return list_mobil.get(row).getTarif_sewa();
            default:
                return null;
        }
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Jenis Mobil";
            case 1:
                return "Tarif Sewa";
            default:
                return null;
        }
//        return super.getColumnName(column); //To change body of generated methods, choose Tools | Templates.
    }
    
}
