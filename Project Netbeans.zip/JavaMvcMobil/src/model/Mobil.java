/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author USER
 */
public class Mobil {
    private int Kd_mobil;
    private String Jenis_mobil;
    private String Warna;
    private int Stok;
    private int Tarif_sewa;
    
    public int getKd_mobil() {
        return Kd_mobil;
    }

    public void setKd_mobil(int Kd_mobil) {
        this.Kd_mobil = Kd_mobil;
    }

    public String getJenis_mobil() {
        return Jenis_mobil;
    }

    public void setJenis_mobil(String Jenis_mobil) {
        this.Jenis_mobil = Jenis_mobil;
    }

    public String getWarna() {
        return Warna;
    }

    public void setWarna(String Warna) {
        this.Warna = Warna;
    }

    public int getStok() {
        return Stok;
    }

    public void setStok(int Stok) {
        this.Stok = Stok;
    }

    public int getTarif_sewa() {
        return Tarif_sewa;
    }

    public void setTarif_sewa(int Tarif_sewa) {
        this.Tarif_sewa = Tarif_sewa;
    }
}
