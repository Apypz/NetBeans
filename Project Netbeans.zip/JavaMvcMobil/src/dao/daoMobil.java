/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package dao;

import controller.Koneksi;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import model.Mobil;

/**
 *
 * @author USER
 */
public class daoMobil implements interfaceMobil {
    
    Connection connection;
    final String insert = "INSERT INTO mobil (Jenis_mobil, Warna, Stok, Tarif_sewa) VALUES (?, ?, ?, ?);";
    final String update = "UPDATE mobil SET Jenis_mobil=?, Warna=?, Stok=?, Tarif_sewa = ? WHERE Kd_mobil=? ;";
    final String delete = "DELETE FROM mobil WHERE Kd_mobil=? ;";
    final String select = "SELECT * FROM mobil ORDER BY Kd_mobil DESC;";

    public daoMobil() {
        connection = Koneksi.connection();
    }
    @Override
    public void insert(Mobil mobil1) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(insert);
            statement.setString(1, mobil1.getJenis_mobil());
            statement.setString(2, mobil1.getWarna());
            statement.setInt(3, mobil1.getStok());
            statement.setInt(4, mobil1.getTarif_sewa());
            statement.executeUpdate();
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Mobil mobil1) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(update);
            statement.setString(1, mobil1.getJenis_mobil());
            statement.setString(2, mobil1.getWarna());
            statement.setInt(3, mobil1.getStok());
            statement.setInt(4, mobil1.getTarif_sewa());
            statement.executeUpdate();
           
        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(int Kd_mobil) {
        PreparedStatement statement = null;
        try {
            statement = connection.prepareStatement(delete);
            statement.setInt(1, Kd_mobil);
            statement.executeUpdate();

        } catch (SQLException ex) {
            ex.printStackTrace();
        } finally {
            try {
                statement.close();
            } catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Mobil> getData() {
        List<Mobil> listMobil = null;
        try {
            listMobil = new ArrayList<Mobil>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()) {
                Mobil mobil1 = new Mobil();
                mobil1.setKd_mobil(rs.getInt("Kd_mobil"));
                mobil1.setJenis_mobil(rs.getString("Jenis_mobil"));
                mobil1.setWarna(rs.getString("Warna"));
                mobil1.setStok(rs.getInt("Stok"));
                mobil1.setTarif_sewa(rs.getInt("Tarif_sewa"));
                listMobil.add(mobil1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(daoMobil.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listMobil;
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
