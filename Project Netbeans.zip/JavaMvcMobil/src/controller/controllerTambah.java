/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.daoMobil;
import dao.interfaceMobil;
import javax.swing.JOptionPane;
import model.Mobil;
import view.viewTambah;
import view.viewUtama;

/**
 *
 * @author USER
 */
public class controllerTambah {
    viewTambah frame;
    interfaceMobil infcMobil;


    public controllerTambah(viewTambah frame) {
         this.frame = frame;
         infcMobil = new daoMobil();
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    
    
    public void tambahData(){
        Mobil mobil_baru = new Mobil();
        mobil_baru.setJenis_mobil(frame.getTxt_jenis().getText());
        mobil_baru.setWarna(frame.getTxt_warna().getText());
        mobil_baru.setStok(Integer.parseInt(frame.getTxt_stok().getText()));
        mobil_baru.setTarif_sewa(Integer.parseInt(frame.getTxt_tarif().getText()));
        

        infcMobil.insert(mobil_baru);
        JOptionPane.showMessageDialog(frame, "Berhasil menambahkan data baru");
        
        kembali();
    }
    
    public void kembali(){
        frame.dispose();
        new viewUtama().setVisible(true);
    }
    
    public void kosongkan_form(){
        frame.setTxt_jenis("");
        frame.setTxt_warna("");
        frame.setTxt_stok("");
        frame.setTxt_tarif("");
    }
}
