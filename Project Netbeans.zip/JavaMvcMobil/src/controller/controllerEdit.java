/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.daoMobil;
import dao.interfaceMobil;
import javax.swing.JOptionPane;
import model.Mobil;
import view.viewEdit;
import view.viewUtama;

/**
 *
 * @author USER
 */
public class controllerEdit {
     viewEdit frame;
    interfaceMobil infcMobil;
    
    public controllerEdit(viewEdit frame) {
        this.frame = frame;
        infcMobil = new daoMobil();
    }
    
    public void tampilkanData(Mobil mobil1){
        frame.setJenis_mobil(mobil1.getJenis_mobil());
        frame.setWarna(mobil1.getWarna());
        frame.setStok(Integer.toString(mobil1.getStok()));
        frame.setTarif_sewa(Integer.toString(mobil1.getTarif_sewa()));
    }
    
    public void simpanEdit(int Kd_mobil){
        Mobil mobil_edit = new Mobil();
        mobil_edit.setJenis_mobil(frame.getTxt_jenis().getText());
        mobil_edit.setWarna(frame.getTxt_warna().getText());
        mobil_edit.setStok(Integer.parseInt(frame.getTxt_stok().getText()));
        mobil_edit.setKd_mobil(Kd_mobil);

        infcMobil.update(mobil_edit);
        JOptionPane.showMessageDialog(frame, "Berhasil mengedit data");
        
        kembali();
    }
    
    public void kembali(){
        frame.dispose();
        new viewUtama().setVisible(true);
    }
}
