/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.daoMobil;
import dao.interfaceMobil;
import model.Mobil;
import view.viewDetail;
import view.viewEdit;
import view.viewUtama;

/**
 *
 * @author USER
 */
public class controllerDetail {
    viewDetail frame;
    interfaceMobil infcMobil;
    
    
    public controllerDetail(viewDetail frame){
        this.frame = frame;
        infcMobil = new daoMobil();
    }
    
    public void tampilkanData(Mobil mobil1){
        frame.setOutJenis_Mobil(mobil1.getJenis_mobil());
        frame.setOutWarna(mobil1.getWarna());
        frame.setOutStok(mobil1.getStok());
        frame.setOutTarif_Sewa(mobil1.getTarif_sewa());
  
    }
    
    public void kembali(){
        frame.dispose();
        new viewUtama().setVisible(true);
    }
    
    public void halaman_edit(Mobil mobil1){
        frame.dispose();
        new viewEdit(mobil1).setVisible(true);
    }
    
    public void hapusData(int Kd_mobil){
        infcMobil.delete(Kd_mobil);
        
        kembali();
    }
    
}
