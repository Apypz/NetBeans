/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;

import dao.daoMobil;
import dao.interfaceMobil;
import java.util.List;
import model.Mobil;
import model.tableModelMobil;
import view.viewDetail;
import view.viewTambah;
import view.viewUtama;

/**
 *
 * @author USER
 */
public class controllerUtama {
    viewUtama frame;
    interfaceMobil infcMobil;
    List<Mobil> list_mobil;

    public controllerUtama(viewUtama frame) {
        this.frame = frame;
        infcMobil = new daoMobil();
        list_mobil = infcMobil.getData();
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void load_table() {
        tableModelMobil tmf = new tableModelMobil(list_mobil);
        frame.getTabelMobil().setModel(tmf);
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void halaman_tambah() {  
        frame.dispose();
        new viewTambah().setVisible(true);
        
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    public void halaman_detail(int row) {
        Mobil mobil1 = list_mobil.get(row);
        frame.dispose();
        new viewDetail(mobil1).setVisible(true);
        
//        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
