/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author Soft11
 */
public class koneksi {
    public class controllerUtama {
    viewUtama frame;
    interfaceFilm infcFilm;
    List<Film> list_film;
    
    public controllerUtama(viewUtama frame) {
        this.frame = frame;
        infcFilm = new daoFilm();
        list_film = infcFilm.getData();
    }
    
    public void load_table() {
        tableModelFilm tmf = new tableModelFilm(list_film);
        frame.getTabelFilm().setModel(tmf);
    }
}

}
