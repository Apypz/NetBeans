/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package model;

/**
 *
 * @author Soft11
 */
public class Film {
       private int id; 

    private String judul; 

    private String sinopsis; 

    private int tahun; 

 

    public int getId() { 

        return id; 

    } 

 

    public void setId(int id) { 

        this.id = id; 

    } 

 

    public String getJudul() { 

        return judul; 

    } 

 

    public void setJudul(String judul) { 

        this.judul = judul; 

    } 

 

    public String getSinopsis() { 

        return sinopsis; 

    } 

 

    public void setSinopsis(String sinopsis) { 

        this.sinopsis = sinopsis; 

    } 

 

    public int getTahun() { 

        return tahun; 

    } 

 

    public void setTahun(int tahun) { 

        this.tahun = tahun; 

    } 

}
