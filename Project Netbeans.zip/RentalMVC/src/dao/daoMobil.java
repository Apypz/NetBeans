package dao;

import controller.koneksi;
import model.Mobil;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.List;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class daoMobil implements interfaceMobil
{
    Connection connection;
    final String insert = "INSERT INTO film (judul,sinopsis,tahun) VALUES (?, ?, ?);";
    final String update = "UPDATE film SET judul=?, sinopsis=?, tahun=? WHERE id=? ;";
    final String delete = "DELETE FROM film WHERE id=? ;";
    final String select = "SELECT * FROM film ORDER BY kd_mobil DESC;";
    
    public daoMobil() {
        connection = koneksi.connection();
    }

    @Override
    public void insert(Mobil mobil1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void update(Mobil mobil1) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void delete(int id) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Mobil> getData() {
        List<Mobil> listMobil = null;
        try {
            listMobil = new ArrayList<Mobil>();
            Statement st = connection.createStatement();
            ResultSet rs = st.executeQuery(select);
            while (rs.next()) {
                Mobil mobil1 = new Mobil();
                mobil1.setKd_mobil(rs.getInt("Kd_mobil"));
                mobil1.setJenis_mobil(rs.getString("Jenis_mobil"));
                mobil1.setWarna(rs.getString("Warna"));
                mobil1.setStok(rs.getInt("Stok"));
                mobil1.setTarif_sewa(rs.getInt("Tarif_sewa"));
                listMobil.add(mobil1);
            }
        } catch (SQLException ex) {
            Logger.getLogger(daoMobil.class.getName()).log(Level.SEVERE, null, ex);
        }

        return listMobil;
    }

    
}
