package dao;

import model.Mobil;
import java.util.List;

public interface interfaceMobil {
    
    public void insert(Mobil mobil1);

    public void update(Mobil mobil1);

    public void delete(int id);

    public List<Mobil> getData();
    
}