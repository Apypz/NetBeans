package controller;

import dao.daoMobil;
import dao.interfaceMobil;
import java.util.List;
import model.Mobil;
import view.viewDetail;
import view.viewUtama;

public class controllerDetail
{
    viewDetail frame;
    interfaceMobil infcFilm;
    
    public controllerDetail(viewDetail frame) {
        this.frame = frame;
        infcFilm = new daoMobil();
    }
    
    public void tampilkanData(Mobil mobil1){
        frame.setOutJenis_mobil(mobil1.getJenis_mobil());
        frame.setOutWarna(mobil1.getWarna());
        frame.setOutStok(mobil1.getStok());
        frame.setOutTarif_sewa(mobil1.getTarif_sewa());
    }
    
    public void kembali(){
        frame.dispose();
        new viewUtama().setVisible(true);
    }
    
//    public void halaman_edit(Film film1){
//        frame.dispose();
//        new viewEdit(film1).setVisible(true);
//    }
//    
//    public void hapusData(int id_film){
//        infcFilm.delete(id_film);
//        
//        kembali();
//    }
}
