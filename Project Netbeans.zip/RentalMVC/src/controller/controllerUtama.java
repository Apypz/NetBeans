package controller;

import dao.daoMobil;
import dao.interfaceMobil;
import java.util.List;
import model.Mobil;
import model.tableModelMobil;
import view.viewDetail;
import view.viewUtama;


public class controllerUtama
{
    viewUtama frame;
    interfaceMobil infcMobil;
    List<Mobil> list_mobil;
    
    public controllerUtama(viewUtama frame) {
        this.frame = frame;
        infcMobil = new daoMobil();
        list_mobil = infcMobil.getData();
    }
    
    public void load_table() {
        tableModelMobil tmf = new tableModelMobil(list_mobil);
        frame.getTabelFilm().setModel(tmf);
    }
//    
//    public void halaman_tambah(){
//        frame.dispose();
//        new viewTambah().setVisible(true);
//    }
//    
    public void halaman_detail(int row){
        Mobil mobil1 = list_mobil.get(row);
        frame.dispose();
        new viewDetail(mobil1).setVisible(true);
    }
}
