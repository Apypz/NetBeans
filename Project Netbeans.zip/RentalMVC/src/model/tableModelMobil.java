package model;

import java.util.List;
import javax.swing.table.AbstractTableModel;

public class tableModelMobil extends AbstractTableModel {
    List<Mobil> list_mobil;

    public tableModelMobil(List<Mobil> list_mobil) {
        this.list_mobil = list_mobil;
    }

    @Override
    public int getColumnCount() {
        return 2;
    }

    @Override
    public int getRowCount() {
        return list_mobil.size();
    }

    @Override
    public String getColumnName(int column) {
        switch (column) {
            case 0:
                return "Jenis Mobil";
            case 1:
                return "Tarif Sewa";
            default:
                return null;
        }
    }

    @Override
    public Object getValueAt(int row, int column) {
        switch (column) {
            case 0:
                return list_mobil.get(row).getJenis_mobil();
            case 1:
                return list_mobil.get(row).getTarif_sewa();
            default:
                return null;
        }
    }
}
