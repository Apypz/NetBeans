package model;

public class Mobil
{
    private int kd_mobil;
    private String jenis_mobil;
    private String warna;
    private int stok;
    private int tarif_sewa;

    public int getKd_mobil() {
        return kd_mobil;
    }

    public void setKd_mobil(int kd_mobil) {
        this.kd_mobil = kd_mobil;
    }

    public String getJenis_mobil() {
        return jenis_mobil;
    }

    public void setJenis_mobil(String jenis_mobil) {
        this.jenis_mobil = jenis_mobil;
    }

    public String getWarna() {
        return warna;
    }

    public void setWarna(String warna) {
        this.warna = warna;
    }

    public int getStok() {
        return stok;
    }

    public void setStok(int stok) {
        this.stok = stok;
    }

    public int getTarif_sewa() {
        return tarif_sewa;
    }

    public void setTarif_sewa(int tarif_sewa) {
        this.tarif_sewa = tarif_sewa;
    }
    
    
}
