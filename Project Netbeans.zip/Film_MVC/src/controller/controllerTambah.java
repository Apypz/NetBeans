/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controller;
import dao.daoFilm;
import dao.interfaceFilm;
import javax.swing.JOptionPane;
import model.Film;
import view.viewUtama;
import view.viewTambah;
/**
 *
 * @author Soft11
 */
public class controllerTambah {
    viewTambah frame;
interfaceFilm infcFilm;

public controllerTambah(viewTambah frame) {
 this.frame = frame;
 infcFilm = new daoFilm();
}

public void tambahData(){
 Film film_baru = new Film();
 film_baru.setJudul(frame.getTxtJudul().getText());
 film_baru.setSinopsis(frame.getTxtSinopsis().getText());
 film_baru.setTahun(Integer.parseInt(frame.getTxtTahun().getText()));
infcFilm.insert(film_baru);
 JOptionPane.showMessageDialog(frame, "Berhasil menambahkan data baru");
 
 kembali();
}

public void kosongkan_form(){
 frame.setTxtJudul("");
 frame.setTxtSinopsis("");
 frame.setTxtTahun("");
}

public void kembali(){
 frame.dispose();
 new viewUtama().setVisible(true);
}
}
